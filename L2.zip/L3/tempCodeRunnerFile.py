if parent_index == 0:
                break

            child_index = parent_index
            parent_index = (child_index - 1) // 2